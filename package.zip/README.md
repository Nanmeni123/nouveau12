# Clarins Display Event Code

## Overview

An Azure function application that authenticate with Cloudi-Fi's API, retrieve an event's code, and serve an HTML page to display it.

The code is cached for 30 seconds, which means that an outdated password may still be displayed for 30 seconds after it has been changed.

## Environment variables

| Name                        | Description                                         |
| --------------------------- | --------------------------------------------------- |
| CLOUDIFI_REFRESH_ENDPOINT   | ex: https://manage-api-v1.cloudi-fi.net/auth/refresh |
| CLOUDIFI_EVENTS_ENDPOINT    | ex: https://manage-api-v1.cloudi-fi.net/events       |
| CLOUDIFI_REFRESH_TOKEN      | A valid refresh token                               |
| CLOUDIFI_EVENT_ID           | ex: 123                                             |


## Deploying the code

### Requirements

On the machine used to build and deploy, there need to be installad

- nodejs version 20+
- npm version 8+
- Azure CLI 2.45+

There are two types of files that need to be deployed to Azure: the configuration files and the javascript files that are the result of the compilation.

### Installing dependencies

```bash
npm install
```

### Build the files

```bash
npm run build
```

### Package the files

```bash
zip package.zip ./*
```

### Deploy to Azure

```bash
# Auhtneticate with an User with enough priviledges to deploy to the Azure Function App
az login

# Locate the function app information
# The CLI has great help built-in. Run any command and subcommand with --help appended to get
# detailed information
az functionapp list --query "[].{resourceGroup: resourceGroup, id: id, name: name}"

# Deploy the zip file
# See: https://learn.microsoft.com/en-us/azure/azure-functions/deployment-zip-push#cli
az functionapp deployment source config-zip -g <resource_group> -n <app_name> --src package.zip
```
