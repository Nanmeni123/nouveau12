const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const InlineChunkHtmlPlugin = require('inline-chunk-html-plugin');

module.exports = {
  mode: 'production',
  entry: ['./src/browser/main.ts', './src/browser/index.scss'],
  module: {
    rules: [
      {
        test: /\.ts$/,
        loader: 'ts-loader',
        exclude: /node_modules/,
        options: {
          configFile: path.resolve(__dirname, 'tsconfig.browser.json'),
        },
      },
      {
        test: /\.html$/,
        loader: 'html-loader',
      },
      {
        test: /\.scss$/,
        use: ['style-loader', 'css-loader', 'sass-loader'],
      },
    ],
  },
  resolve: {
    extensions: ['.ts'],
  },
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'dist', 'browser'),
  },
  plugins: [
    // These two plugins work together to embed the browser javascript into the html file
    new HtmlWebpackPlugin({ template: 'src/browser/index.html' }),
    new InlineChunkHtmlPlugin(HtmlWebpackPlugin, [/main/]),
  ],
};
