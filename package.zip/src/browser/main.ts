const getUrlPrefix = () => {
  const { pathname } = window.location;

  // pathname looks like "/some_prefix/get-page"
  // we need "some_prefix" actual value to fetch the code
  const [ignore, prefix, methodName] = pathname.split('/');
  return prefix;
};

/*
  Illustrate how to make a ajax request that fetches the code from the server
*/
const fetchCode = () => {
  return fetch(`/${getUrlPrefix()}/get-code`)
    .then((response) => response.json())
    .then(({ code }) => code)
    .catch((e) => console.error(e));
};
