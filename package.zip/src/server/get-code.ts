import { fileCache } from './server-cache.js';

const httpTrigger = async function (context, req) {
  try {
    const code = await fileCache.getCode();
    context.res = {
      status: 200,
      body: JSON.stringify({ code }),
      headers: {
        ['content-type']: 'application/json',
      },
    };
  } catch (e) {
    context.log.error(e);
    context.res = {
      status: 500,
      body: `An error has occurred.`,
    };
  }
};

export default httpTrigger;
