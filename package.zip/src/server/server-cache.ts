import { add, isAfter } from 'date-fns';
import * as fs from 'fs';
import { default as fetch } from 'node-fetch';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { MissingConfigurationException } from './missing-configuration.exception.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const htmlIndexFile = path.resolve(__dirname, '..', 'browser/index.html');

const cacheMaxAge = { minutes: 5 };
const codeMaxAge = { seconds: 30 };
const tokenMaxAge = { hours: 12 };

type Cached<T = any> = {
  timestamp: Date;
  data: T;
};

class Cache {
  private file?: Cached<string>;
  private code?: Cached<string>;
  private token?: Cached<string>;

  constructor() {}

  checkFileCacheAge() {
    if (
      this.file?.timestamp &&
      isAfter(new Date(), add(this.file.timestamp, cacheMaxAge))
    ) {
      this.file = undefined;
    }
  }

  checkTokenCacheAge() {
    if (
      this.token?.timestamp &&
      isAfter(new Date(), add(this.token.timestamp, tokenMaxAge))
    ) {
      this.token = undefined;
    }
  }

  checkCodeCacheAge() {
    if (
      this.code?.timestamp &&
      isAfter(new Date(), add(this.code?.timestamp, codeMaxAge))
    ) {
      this.code = undefined;
    }
  }

  getIndexHtml() {
    this.checkFileCacheAge();
    if (!this.file) {
      this.file = {
        data: fs.readFileSync(htmlIndexFile, 'utf-8'),
        timestamp: new Date(),
      };
    }
    return this.file.data;
  }

  async getCode() {
    this.checkCodeCacheAge();

    if (!this.code?.data) {
      const data = await this.fetchCode();
      this.code = { data, timestamp: new Date() };
    }

    return this.code.data;
  }

  async getToken() {
    this.checkTokenCacheAge();

    if (!this.token?.data) {
      const data = await this.fetchToken();
      this.token = { data, timestamp: new Date() };
    }

    return this.token.data;
  }

  async fetchToken() {
    const refreshToken = process.env['CLOUDIFI_REFRESH_TOKEN'];
    const refreshEndpoint = process.env['CLOUDIFI_REFRESH_ENDPOINT'];

    if (!(refreshToken && refreshEndpoint)) {
      throw new MissingConfigurationException();
    }

    const payload = {
      refresh_token: refreshToken,
    };

    try {
      const result = await fetch(refreshEndpoint, {
        method: 'POST',
        body: JSON.stringify(payload),
        headers: { 'content-type': 'application/json' },
      });

      const responseBody = await result.json();

      if (responseBody?.token) {
        return responseBody.token;
      } else {
        throw new Error(
          `No token was returned. ${JSON.stringify(responseBody)}`
        );
      }
    } catch (e) {
      throw new Error(
        `Impossible to retrieve a valid token. ${e.message} ${refreshEndpoint}`
      );
    }
  }

  async fetchCode() {
    const eventsEndpont = process.env['CLOUDIFI_EVENTS_ENDPOINT'];
    const eventId = process.env['CLOUDIFI_EVENT_ID'];

    const url = `${eventsEndpont}/${eventId}`;
    const token = await this.getToken();
    const result = await fetch(url, {
      headers: {
        authorization: `Bearer ${token}`,
      },
    });
    const responseBody = await result.json();
    if (responseBody?.passcode) {
      return responseBody.passcode;
    } else {
      throw new Error(
        `No code.\n  ${url}\n  ${token}\n  ${JSON.stringify(responseBody)}`
      );
    }
  }
}
export const fileCache = new Cache();
