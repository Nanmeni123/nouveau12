export class MissingConfigurationException extends Error {
  constructor() {
    super(
      'Missing configuration. CLOUDIFI_ADMIN_USERNAME, CLOUDIFI_ADMIN_PASSWORD and CLOUDIFI_TOKEN_ENDPOINT are mandatory.'
    );
  }
}
