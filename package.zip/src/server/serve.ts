import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const htmlIndexFile = path.resolve(__dirname, '..', 'browser/index.html');

class Cache {
  private content?: string;

  getIndexHtml() {
    if (!this.content) {
      this.content = fs.readFileSync(htmlIndexFile, 'utf-8');
    }

    return this.content;
  }
}

const fileCache = new Cache();

export const httpTrigger = async function (context, req) {
  const file = fileCache.getIndexHtml();
  context.res = {
    status: 200,
    body: file,
    headers: {
      ['content-type']: 'text/html',
    },
  };
};

export default httpTrigger;
