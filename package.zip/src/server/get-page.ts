import { Context } from '@azure/functions';
import { fileCache } from './server-cache.js';

const httpTrigger = async function (context: Context, req) {
  const file = fileCache.getIndexHtml();

  try {
    const code = await fileCache.getCode();

    context.res = {
      status: 200,
      body: file.replace(/{% code %}/, code),
      headers: {
        ['content-type']: 'text/html',
      },
    };
  } catch (e) {
    context.log.error(e.message);

    context.res = {
      status: 200,
      body: file.replace(/{% code %}/, ''),
      headers: {
        ['content-type']: 'text/html',
      },
    };
  }
};
export default httpTrigger;
